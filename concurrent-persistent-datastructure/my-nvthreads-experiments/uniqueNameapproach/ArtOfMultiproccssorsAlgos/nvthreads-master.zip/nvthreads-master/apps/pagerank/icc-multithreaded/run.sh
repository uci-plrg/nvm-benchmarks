./prr-pt /scratch/bruegner/adj_livejournal_snap 2 12 68993773 output.txt
